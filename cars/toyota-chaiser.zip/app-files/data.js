var APP_DATA = {
  "scenes": [
    {
      "id": "0-toyota-chaiser",
      "name": "toyota chaiser",
      "levels": [
        {
          "tileSize": 256,
          "size": 256,
          "fallbackOnly": true
        },
        {
          "tileSize": 512,
          "size": 512
        },
        {
          "tileSize": 512,
          "size": 1024
        },
        {
          "tileSize": 512,
          "size": 2048
        }
      ],
      "faceSize": 1824,
      "initialViewParameters": {
        "yaw": 3.026175065589781,
        "pitch": 0.3237739845720675,
        "fov": 1.35820747241737
      },
      "linkHotspots": [],
      "infoHotspots": []
    }
  ],
  "name": "toyota chaiser",
  "settings": {
    "mouseViewMode": "drag",
    "autorotateEnabled": false,
    "fullscreenButton": true,
    "viewControlButtons": true
  }
};
