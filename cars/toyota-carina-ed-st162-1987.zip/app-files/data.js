var APP_DATA = {
  "scenes": [
    {
      "id": "0-toyota-carina-ed-st162-1987",
      "name": "toyota carina ed st162 1987",
      "levels": [
        {
          "tileSize": 256,
          "size": 256,
          "fallbackOnly": true
        },
        {
          "tileSize": 512,
          "size": 512
        },
        {
          "tileSize": 512,
          "size": 1024
        },
        {
          "tileSize": 512,
          "size": 2048
        }
      ],
      "faceSize": 1824,
      "initialViewParameters": {
        "yaw": -0.28331082313687084,
        "pitch": 0.2718068890184284,
        "fov": 1.35820747241737
      },
      "linkHotspots": [],
      "infoHotspots": []
    }
  ],
  "name": "toyota carina ed st162 1987",
  "settings": {
    "mouseViewMode": "drag",
    "autorotateEnabled": false,
    "fullscreenButton": true,
    "viewControlButtons": true
  }
};
